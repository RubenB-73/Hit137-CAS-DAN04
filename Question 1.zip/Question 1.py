
def encrypt_with_log(text, n, m):
    encrypted = []
    log = []  # Store transformation instructions per character
    for char in text:
        if char.islower():
            if char <= 'm':
                shift = n * m
                new_char = chr((ord(char) - ord('a') + shift) % 26 + ord('a'))
                log.append('lf')  # lowercase forward
            else:
                shift = n + m
                new_char = chr((ord(char) - ord('a') - shift) % 26 + ord('a'))
                log.append('lb')  # lowercase backward
            encrypted.append(new_char)
        elif char.isupper():
            if char <= 'M':
                shift = n
                new_char = chr((ord(char) - ord('A') - shift) % 26 + ord('A'))
                log.append('ub')  # uppercase backward
            else:
                shift = m ** 2
                new_char = chr((ord(char) - ord('A') + shift) % 26 + ord('A'))
                log.append('uf')  # uppercase forward
            encrypted.append(new_char)
        else:
            encrypted.append(char)
            log.append('--')  # No transformation
    return ''.join(encrypted), log

def decrypt_with_log(encrypted_text, log, n, m):
    decrypted = []
    for char, instruction in zip(encrypted_text, log):
        if instruction == 'lf':
            shift = n * m
            new_char = chr((ord(char) - ord('a') - shift) % 26 + ord('a'))
        elif instruction == 'lb':
            shift = n + m
            new_char = chr((ord(char) - ord('a') + shift) % 26 + ord('a'))
        elif instruction == 'ub':
            shift = n
            new_char = chr((ord(char) - ord('A') + shift) % 26 + ord('A'))
        elif instruction == 'uf':
            shift = m ** 2
            new_char = chr((ord(char) - ord('A') - shift) % 26 + ord('A'))
        else:
            new_char = char
        decrypted.append(new_char)
    return ''.join(decrypted)

def check_correctness(original, decrypted):
    return original == decrypted

def main():
    n = int(input("Enter value for n: "))
    m = int(input("Enter value for m: "))

    with open("raw_text.txt", "r") as f:
        original_text = f.read()

    encrypted_text, log_data = encrypt_with_log(original_text, n, m)
    with open("encrypted_text.txt", "w") as f:
        f.write(encrypted_text)
    with open("encryption_log.txt", "w") as f:
        f.write(','.join(log_data))

    decrypted_text = decrypt_with_log(encrypted_text, log_data, n, m)
    is_correct = check_correctness(original_text, decrypted_text)

    print("Encryption complete. Decryption check passed:", is_correct)

if __name__ == "__main__":
    main()
